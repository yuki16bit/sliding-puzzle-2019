import React from 'react';

const Tile = () => {
  return <button>11111</button>;
}

export default Tile;
