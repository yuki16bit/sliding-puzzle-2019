import React from 'react';

const Info = () => {
  return (
    <div>
      <label />
      <input />
    </div>
  )
}

export default Info;
