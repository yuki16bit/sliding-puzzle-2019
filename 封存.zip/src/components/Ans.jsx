import React from 'react';

const Ans = () => {
  return (
    <div>
      <img src/>
    </div>
  )
}

export default Ans;
